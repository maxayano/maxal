import React, { useState } from 'react';
import axios from 'axios';

const PDFUploader = ({ onExtractText }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleFileUpload = async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        setIsLoading(true);
        setError(null);

        const formData = new FormData();
        formData.append('pdf', file);

        try {
            const response = await axios.post('http://localhost:3001/upload', formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            onExtractText(response.data.text);
        } catch (err) {
            setError('Failed to process PDF. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div>
            <input type="file" accept="application/pdf" onChange={handleFileUpload} />
            {isLoading && <p>Processing PDF...</p>}
            {error && <p style={{ color: 'red' }}>{error}</p>}
        </div>
    );
};

export default PDFUploader;
