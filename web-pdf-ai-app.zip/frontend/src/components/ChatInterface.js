import React, { useState } from 'react';
import axios from 'axios';

const ChatInterface = ({ pdfText }) => {
    const [question, setQuestion] = useState('');
    const [messages, setMessages] = useState([]);

    const handleSendMessage = async () => {
        if (!question) return;

        setMessages([...messages, { text: question, isUser: true }]);
        setQuestion('');

        try {
            const response = await axios.post('http://localhost:3001/ask', {
                question,
                context: pdfText,
            });
            setMessages([
                ...messages,
                { text: question, isUser: true },
                { text: response.data.answer, isUser: false },
            ]);
        } catch (error) {
            setMessages([
                ...messages,
                { text: question, isUser: true },
                { text: 'Error processing request.', isUser: false },
            ]);
        }
    };

    return (
        <div>
            <div style={{ height: '300px', overflowY: 'scroll', border: '1px solid #ccc', padding: '10px' }}>
                {messages.map((msg, index) => (
                    <p key={index} style={{ textAlign: msg.isUser ? 'right' : 'left' }}>
                        {msg.text}
                    </p>
                ))}
            </div>
            <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ask a question..."
                style={{ width: '80%', marginRight: '10px' }}
            />
            <button onClick={handleSendMessage}>Send</button>
        </div>
    );
};

export default ChatInterface;
