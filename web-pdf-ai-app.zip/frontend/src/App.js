import React, { useState } from 'react';
import PDFUploader from './components/PDFUploader';
import ChatInterface from './components/ChatInterface';

const App = () => {
    const [pdfText, setPdfText] = useState(null);

    return (
        <div style={{ padding: '20px' }}>
            <h1>PDF AI Assistant</h1>
            <PDFUploader onExtractText={(text) => setPdfText(text)} />
            {pdfText && <ChatInterface pdfText={pdfText} />}
        </div>
    );
};

export default App;
