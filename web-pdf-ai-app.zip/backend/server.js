const express = require('express');
const multer = require('multer');
const bodyParser = require('body-parser');
const pdfParse = require('pdf-parse');
const { Configuration, OpenAIApi } = require('openai');

const app = express();
const upload = multer();
app.use(bodyParser.json());

const configuration = new Configuration({
    apiKey: 'YOUR_OPENAI_API_KEY',
});
const openai = new OpenAIApi(configuration);

app.post('/upload', upload.single('pdf'), async (req, res) => {
    try {
        const data = await pdfParse(req.file.buffer);
        res.json({ text: data.text });
    } catch (error) {
        res.status(500).json({ error: 'Failed to parse PDF.' });
    }
});

app.post('/ask', async (req, res) => {
    const { question, context } = req.body;
    if (!question || !context) {
        return res.status(400).json({ error: 'Question and context are required.' });
    }

    try {
        const response = await openai.createCompletion({
            model: 'text-davinci-003',
            prompt: `Context: ${context}\nQuestion: ${question}`,
            max_tokens: 150,
            temperature: 0.7,
        });
        res.json({ answer: response.data.choices[0].text.trim() });
    } catch (error) {
        res.status(500).json({ error: 'Failed to get response from OpenAI.' });
    }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
